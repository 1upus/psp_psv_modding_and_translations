-- ui/credits.lua

-- using default named events script 'ui/credits-events.lua'

CreateComp ("Rectangle", "bg");
SetProperty ("inherit", "BlackBackground");
SetProperty ("position", 0.5, 0.5);
SetProperty ("align", "CENTER");

CreateComp ("TouchField", "TF");
SetProperty ("position", 0.498808, 0.494203);
SetProperty ("align", "CENTER");
SetProperty ("touchfield.area_width", 1000.91);
SetProperty ("touchfield.area_height", 631.913);
SetProperty ("touchfield.content_width", 974.708);
SetProperty ("touchfield.content_height", 2683.67);
SetProperty ("touchfield.axis_x_enabled", 0);
SetProperty ("touchfield.clip_children", 0);

CreateComp ("Image", "logo");
SetProperty ("parent", "TF");
SetProperty ("position", 0.000551787, 0.00693156);
SetProperty ("scale", 0.925196);
SetProperty ("align", "CENTER");
SetProperty ("image.bitmap", "ui/gfx/game-logo.png");

CreateComp ("Image", "logo_glow");
SetProperty ("blend_mode", "ADDITIVE");
SetProperty ("parent", "logo");
SetProperty ("position", -0.00169141, 0.00459456);
SetProperty ("align", "CENTER");
SetProperty ("image.bitmap", "ui/gfx/game-logo-glow.png");

CreateComp ("Marker", "credits");
SetProperty ("parent", "TF");
SetProperty ("position", 0.0013466, 0.46818);
SetProperty ("align", "HCENTER");
SetProperty ("marker.area_width", 876.987);
SetProperty ("marker.area_height", 402.185);

CreateComp ("Textbox", "ta2_HASO");
SetProperty ("inherit", "MediumTextbox");
SetProperty ("localize", 0);
SetProperty ("parent", "credits");
SetProperty ("position", -0.00100402, 0.65511);
SetProperty ("scale", 0.692378);
SetProperty ("align", "CENTER");
SetProperty ("textbox.textbox_align", "HCENTER");
SetProperty ("textbox.text", "TERO ALATALO\nMIKKO HEIKKILA\nSAMPO TOYSSY\nOLLI ALATALO\nVELI NYSTROM");

CreateComp ("Textbox", "original_crimsonland");
SetProperty ("inherit", "MediumTextbox");
SetProperty ("parent", "credits");
SetProperty ("position", -0.000836756, 1.75867);
SetProperty ("align", "HCENTER");
SetProperty ("textbox.text", "Crimsonland (2003) Credits and Thanks");

CreateComp ("Textbox", "original_crimsonland2");
SetProperty ("inherit", "MediumTextbox");
SetProperty ("parent", "credits");
SetProperty ("position", -0.00218559, 0.35031);
SetProperty ("align", "HCENTER");
SetProperty ("textbox.text", "Created By");

CreateComp ("Textbox", "original_crimsonland3");
SetProperty ("inherit", "MediumTextbox");
SetProperty ("parent", "credits");
SetProperty ("position", -0.00144516, 1.0347);
SetProperty ("align", "HCENTER");
SetProperty ("textbox.text", "Testing & Feedback");

CreateComp ("Textbox", "qapeople");
SetProperty ("inherit", "MediumTextbox");
SetProperty ("localize", 0);
SetProperty ("parent", "original_crimsonland");
SetProperty ("position", -0.000326689, 1.89061);
SetProperty ("scale", 0.758319);
SetProperty ("align", "HCENTER");
SetProperty ("textbox.textbox_align", "HCENTER");
SetProperty ("textbox.text", "Zach Young\nIon Hardie\nTimo Palonen\nValtteri Pihlajamaki\nVille Eriksson\nMiikka Kulmala\nPetri Jarvilehto\nPeter Hajba\nJeff McAteer");

CreateComp ("Textbox", "qapeople3");
SetProperty ("inherit", "MediumTextbox");
SetProperty ("localize", 0);
SetProperty ("parent", "original_crimsonland3");
SetProperty ("position", 0.00299189, 1.92278);
SetProperty ("scale", 0.755774);
SetProperty ("align", "HCENTER");
SetProperty ("textbox.textbox_align", "HCENTER");
SetProperty ("textbox.text", "Jaakko Maaniemi\nMarkus Jylha\nMiikka Kulmala\nBrady Cash\nDmitriy '$LEp()y' Ozhegov\nHenri Makela");

CreateComp ("Textbox", "qapeople2");
SetProperty ("inherit", "MediumTextbox");
SetProperty ("localize", 0);
SetProperty ("parent", "original_crimsonland");
SetProperty ("position", -0.00373651, 9.86475);
SetProperty ("scale", 0.656859);
SetProperty ("align", "HCENTER");
SetProperty ("textbox.textbox_align", "HCENTER");
SetProperty ("textbox.text", "Avraham Petrosyan\nBryce Baker\nDan Ruskin\nDirk Bunk\nEric Dallaire\nErik Van Pelt\nErnie Ramirez\nJames C. Smith\nJarkko Forsbacka\nKalle Hahl\nLars Brubaker\nLee Cooper\nMarkus Lassila\nMatti Alanen\nMika Alatalo\nJuha Alatalo\nMike Colonnese\nSimon Hallam\nToni Nurminen\nVille Mantyla");

CreateComp ("Image", "10tons");
SetProperty ("parent", "credits");
SetProperty ("position", -0.0112091, 4.34257);
SetProperty ("align", "CENTER");
SetProperty ("image.bitmap", "10tons/10tons-logo-white.png");

CreateComp ("Textbox", "licenses");
SetProperty ("inherit", "SmallTextbox");
SetProperty ("parent", "TF");
SetProperty ("position", 0.00228868, 2.87892);
SetProperty ("align", "BOTTOMHCENTER");
SetProperty ("textbox.text", "Uses Lua, libjpg, and libpng. See 10tons.com/LicencesUsed.html");

CreateComp ("Textbox", "SecretText");
SetProperty ("inherit", "SmallTextbox");
SetProperty ("parent", "TF");
SetProperty ("position", 0.000335974, 3.61129);
SetProperty ("align", "BOTTOMHCENTER");
SetProperty ("expanded_hit_area", 15);
SetProperty ("textbox.text", "There is something hidden here.");

CreateComp ("Image", "by10tons");
SetProperty ("parent", "credits");
SetProperty ("position", -0.380911, -0.963041);
SetProperty ("align", "HCENTER");
SetProperty ("image.bitmap", "10tons/10tons-logo-white.png");

CreateComp ("Button", "Done");
SetProperty ("inherit", "SmallSquareButton");
SetProperty ("localize", 0);
SetProperty ("position", 0.947009, 0.0816888);
SetProperty ("scale", 0.712447);
SetProperty ("button.text", "X");

CreateComp ("Marker", "untitled_1");
SetProperty ("parent", "TF");
SetProperty ("position", -0.00494781, 3.69625);
SetProperty ("align", "CENTER");

CreateComp ("NinePatch", "untitled_3");
SetProperty ("inherit", "NinePatchWhiteLine");
SetProperty ("parent", "credits");
SetProperty ("position", -0.00241499, 0.436687);
SetProperty ("align", "CENTER");
SetProperty ("ninepatch.client_size", 237, 2);

CreateComp ("NinePatch", "untitled_5");
SetProperty ("inherit", "NinePatchWhiteLine");
SetProperty ("parent", "original_crimsonland3");
SetProperty ("position", -0.00250787, 1.08447);
SetProperty ("align", "CENTER");
SetProperty ("ninepatch.client_size", 493, 3);

CreateComp ("NinePatch", "untitled_4");
SetProperty ("inherit", "NinePatchWhiteLine");
SetProperty ("parent", "original_crimsonland");
SetProperty ("position", -0.0016093, 1.14554);
SetProperty ("align", "CENTER");
SetProperty ("ninepatch.client_size", 691, 3);

CreateComp ("Textbox", "Version");
SetProperty ("localize", 0);
SetProperty ("parent", "logo");
SetProperty ("position", 0.449935, 0.367196);
SetProperty ("align", "RIGHTVCENTER");
SetProperty ("textbox.text", "Version 1.0.0");

